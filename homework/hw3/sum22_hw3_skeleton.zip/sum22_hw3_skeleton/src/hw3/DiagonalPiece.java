package hw3;

import api.Icon;
import api.Cell;
import api.Position;

public class DiagonalPiece extends AbstractPiece {

	public DiagonalPiece(Position position, Icon[] icons) {
		super(position);
		// TODO:
	}

	@Override
	public void transform() {
		// TODO:
	}
}
