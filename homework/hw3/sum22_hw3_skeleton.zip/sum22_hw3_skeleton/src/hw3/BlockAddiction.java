
package hw3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import api.AbstractGame;
import api.Generator;
import api.Icon;
import api.Position;


public class BlockAddiction extends AbstractGame {

	public BlockAddiction(int height, int width, Generator gen) {
		super(height, width, gen);
		// TODO
	}

	public BlockAddiction(int height, int width, Generator gen, int preFillRows) {
		super(height, width, gen);
		// TODO
	}

	@Override
	public List<Position> determinePositionsToCollapse() {
		// TODO
		return null;
	}

	private void preFill(int rows, Generator gen) {
		// TODO
	}
}
