package hw3;

import api.Icon;
import api.Cell;
import api.Position;
import api.Piece;

/**
 * Abstract superclass for implementations of the Piece interface.
 */
public abstract class AbstractPiece implements Piece {

	/**
	 * Constructs a piece with the given position. Subclasses extending this class
	 * MUST call setCells to initialize initial cell positions and icons.
	 * 
	 * @param position initial position for upper-left corner of bounding box
	 */
	protected AbstractPiece(Position position) {
		// TODO Auto-generated method stub
	}

	@Override
	public Position getPosition() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setCells(Cell[] givenCells) {
		// TODO Auto-generated method stub

	}

	@Override
	public Cell[] getCells() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Cell[] getCellsAbsolute() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void shiftDown() {
		// TODO Auto-generated method stub

	}

	@Override
	public void shiftLeft() {
		// TODO Auto-generated method stub

	}

	@Override
	public void shiftRight() {
		// TODO Auto-generated method stub

	}

	@Override
	public void cycle() {
		// TODO Auto-generated method stub

	}

	@Override
	public Piece clone() {
		// TODO Auto-generated method stub
		return null;
	}

}