package hw3;

import api.Cell;
import api.Icon;
import api.Position;

public class LPiece extends AbstractPiece {

	public LPiece(Position position, Icon[] icons) {
		super(position);
		// TODO
	}

	@Override
	public void transform() {
		// TODO
	}
}
