package hw3;

import api.Cell;
import api.Icon;
import api.Position;

public class SnakePiece extends AbstractPiece
{
  /**
   * Sequence of positions for the first cell.
   */
  private static final Position[] sequence = {
      new Position(0, 0),
      new Position(0, 1),
      new Position(0, 2),
      new Position(1, 2),
      new Position(1, 1),
      new Position(1, 0),    
      new Position(2, 0),
      new Position(2, 1),
      new Position(2, 2),
      new Position(1, 2),
      new Position(1, 1),
      new Position(1, 0),
  };
  
 
  public SnakePiece(Position position, Icon[] icons) {
    super(position);
    // TODO
  }

  @Override
  public void transform() {
    // TODO
  }
}
